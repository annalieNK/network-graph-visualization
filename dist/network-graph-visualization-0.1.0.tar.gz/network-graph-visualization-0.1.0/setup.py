# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['network_graph_visualization']

package_data = \
{'': ['*']}

install_requires = \
['Sphinx>=3.5.1,<4.0.0',
 'matplotlib>=3.3.4,<4.0.0',
 'networkx>=2.5,<3.0',
 'pandas>=1.2.2,<2.0.0',
 'plotly>=4.14.3,<5.0.0',
 'setuptools>=54.1.0,<55.0.0',
 'twine>=3.3.0,<4.0.0']

setup_kwargs = {
    'name': 'network-graph-visualization',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.6,<4.0.0',
}


setup(**setup_kwargs)
