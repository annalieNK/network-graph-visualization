# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['network_graph_visualization']

package_data = \
{'': ['*']}

install_requires = \
['Sphinx>=3.5.1,<4.0.0',
 'matplotlib>=3.3.4,<4.0.0',
 'networkx>=2.5,<3.0',
 'pandas>=1.2.2,<2.0.0',
 'plotly>=4.14.3,<5.0.0']

setup_kwargs = {
    'name': 'network-graph-visualization',
    'version': '0.1.0',
    'description': 'This package creates a visualization of a network graph with its attributes displayed.',
    'long_description': 'This package creates a visualization of a network graph built with\nNetworkx with hovering functions by Plotly.\n\nMultiple node and edge attributes can be added to the network and shown\nin the visualization.\n\nPrerequisites\n-------------\n\nThis package requires networkx version >= 2.5 and plotly version >=\n4.14.3. See ``pyproject.toml`` for the complete prerequisites.\n\nInstallation\n------------\n\nInstall the package through\n\n::\n\n   test\n\nUsage\n-----\n\nBelow is an example how to use this package. This description also shows\nhow to add node and edge attributes to the graph from the corresponding\npandas dataframes.\n\n**Create two separate dataframes.** One with information about the nodes and\none with information about the connections. For simplicity, call them\n``connections_df`` and ``nodes_df``.\n\n::\n\n   connections_df = pd.read_csv(CONNECTIONS_FILENAME)\n   nodes_df = pd.read_csv(NODES_FILENAME)\n\n**Build an empty graph.**\n\n::\n\n   G = nx.Graph()\n\n**Add edge attributes.** Create a column of connections as input for\nNetworkx. Set these as the index, Convert dataframe to dictionary where\nthe indices are the key and the attributes the values. Add edges and\ntheir attributes to empty graph.\n\n::\n\n   connections_df[\'connections\'] = list(zip(connections_df[\'SOURCE_VARIABLE\'], connections_df[\'TARGET_VARIABLE\']))\n   connections_temp = connections_df[[\'connections\', \'EDGE_ATTRIBUTE_1\', \'EDGE_ATTRIBUTE_2\']].set_index(\'connections\')\n   connections_dict = connections_temp.to_dict(\'index\')\n   G.add_edges_from((k[0], k[1], d) for k,d in connections_dict.items())\n\n**Add node attributes.** In contrast to edge attributes node attributes can\nbe added all at once.\n\n::\n\n   nodes_temp = nodes_df.set_index(\'NODE_NAME_VARIABLE\')\n   nodes_dict = nodes_temp.to_dict(\'index\')\n   nx.set_node_attributes(G, nodes_dict)\n\n**Call the package.**\n\n::\n\n   import plot\n   network_plot = plot.GraphNetwork(G)\n\n**View graph attributes.**\n\n::\n\n   print(network_plot.G.nodes(data=True))\n   print(network_plot.G.edges(data=True))\n\n**Optional to add all node and edge attributes as hovering text.**\n\n**Add node hover text.**\n\n::\n\n   NODE_HOVERTEXT = []\n   for node in G.nodes():\n       NODE_HOVERTEXT.append(\n                       "Name: " + node + "<br>" + \\\n                       "NODE_ATTRIBUTE_1: " + str(network_plot.G.nodes[node][\'NODE_ATTRIBUTE_1\']) + "<br>" + \\\n                       "NODE_ATTRIBUTE_2: " + str(network_plot.G.nodes[node][\'NODE_ATTRIBUTE_2\'])\n                       )\n\n**Add edge hover text.**\n\n::\n\n   EDGE_HOVERTEXT = []\n   for edge in G.edges():\n       EDGE_HOVERTEXT.append(\n                       "EDGE_ATTRIBUTE_1: " + str(G.edges[edge][\'EDGE_ATTRIBUTE_1\']) + "<br>" + \\\n                       "EDGE_ATTRIBUTE_2: " + str(G.edges[edge][\'EDGE_ATTRIBUTE_2\'])\n                       )\n\n**Run node and edge traces.**\n\n::\n\n   network_plot.trace_nodes(node_color_variable=\'NODE_ATTRIBUTE_1\', node_text=NODE_HOVERTEXT)\n   network_plot.trace_edges(edge_text=EDGE_HOVERTEXT) #edge_attribute=\'EDGE_ATTRIBUTE_2\'\n\n**Build visualization.**\n\n::\n\n   network_plot.visualization_attributes(title=\'TITLE OF THE PLOT\')\n\n**Draw and visualize the network.**\n\n::\n\n   network_plot.draw_network(graph_filename=\'GRAPH_FILENAME.html\')',
    'author': 'Annalie Kruseman',
    'author_email': 'annaliakruseman@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/annalieNK/network-graph-visualization',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.6,<4.0.0',
}


setup(**setup_kwargs)
